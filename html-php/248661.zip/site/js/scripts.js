$(window).load(function(){
    
    // ieCheck
    var ie = false;
    var aniButtonDuration = 350;
	
	MSIE = ($.browser.msie) && ($.browser.version <= 8);
    
    if($.browser.msie && $.browser.version<9)
    {
        aniButtonDuration = 0;
        ie = true;
    }
    
    
    $('.gall_spinner').hide();
    $('#bgStretch')
		.bgStretch({
			align:'rightTop',
			navigs:$('#bgNav').navigs({prevBtn:$('#prev_arr'), nextBtn:$('#next_arr')})
		}).sImg({
			spinner:$('.gall_spinner')
		}) 
        
    $('#prev_arr, #next_arr')
	.sprites({
		method:'simple',
		duration:400,
		easing:'easeOutQuint',
		hover:true
	})
     
	 
	$(".downScroll_1").hoverSprite({onLoadWebSite: true});
	$(".upScroll_1").hoverSprite({onLoadWebSite: true});
	
	$(".downScroll_3").hoverSprite({onLoadWebSite: true});
	$(".upScroll_3").hoverSprite({onLoadWebSite: true});
	
	$(".downScroll_more").hoverSprite({onLoadWebSite: true});
	$(".upScroll_more").hoverSprite({onLoadWebSite: true});

	$('.scroll_1').uScroll({mousewheel:true, step:98});
	$('.scroll_2').uScroll({mousewheel:true, step:170});
	$('.scroll_3').uScroll({mousewheel:true, step:466});
	$('.scroll').uScroll({mousewheel:true, step:98})

	$('.more1').hover(
        function(){
            $(this).stop().animate({'backgroundPosition':'center bottom', color:'#fff'},700,'easeOutExpo');
			},
        function(){
			$(this).stop().animate({'backgroundPosition':'center top', color:'#fff'},700,'easeOutExpo');
			}
		);
	$('.more2').hover(
        function(){
            $(this).stop().animate({'backgroundPosition':'center bottom', color:'#fff'},700,'easeOutExpo');
			},
        function(){
			$(this).stop().animate({'backgroundPosition':'center top', color:'#fff'},700,'easeOutExpo');
			}
		);
	 
    $('').each(function(){
        $(this).find('>span').stop().animate({opacity:0},0);
        $(this).hover(function()
        {
            $(this).find('>span').stop().animate({opacity:1}, aniButtonDuration,'easeOutCubic')					   
        }, function(){
        	$(this).find('>span').stop().animate({opacity:0}, aniButtonDuration,'easeOutCubic')						   
        })
    })
	 
	
	//slider tours----------------------------------------------
	 if ($(".slider1").length) {
        $('.slider1').cycle({
            fx: 'scrollHorz',
            speed: 600,
    		timeout: 0,
            next: '.next',
    		prev: '.prev',                
    		easing: 'easeInOutExpo',
    		cleartypeNoBg: true ,
            rev:0,
            startingSlide: 0,
            wrap: true
  		})
    };
    var ind = 0;
    var len = $('.nav_item').length;
    $('.nav_item').bind('click',function(){
        ind = $(this).index()-0;
        $('.nav_item').each(function(index,elem){if (index!=(ind)){$(this).removeClass('active');}});
        $(this).addClass('active');
        $('.slider1').cycle(ind);
		return false;
    });
	
	slider_01();
	
	
	
	function slider_01(){
	
		  $('#page_news .nav_events span').css({opacity:0})
		
		var slider_01 = $(".nav_item, .next").hover(bannerOverHandler, bannerOutHandler);
		
		function bannerOverHandler(){

			$(this).find('span').stop().animate({opacity:1});
			
		}
		function bannerOutHandler(){
		
			$(this).find('span').stop().animate({opacity:0});
			
		}
	}
		
		
    $('.prev').bind('click',function(e){
        if (ind>-1){
            ind--;
            $('.nav_item').each(function(index,elem){if (index!=(ind)){$(this).removeClass('active');}});
            $('.nav_item').eq(ind).addClass('active');
        }
		if (ind==-1){
            ind=(len-1)
            $('.nav_item').each(function(index,elem){if (index!=(ind)){$(this).removeClass('active');}});
            $('.nav_item').eq(ind).addClass('active');
        }
		
    });
     $('.next').bind('click',function(e){
	 
        if (ind<(len)){
            ind++;
            $('.nav_item').each(function(index,elem){if (index!=(ind)){$(this).removeClass('active');}});
            $('.nav_item').eq(ind).addClass('active');
        }
		if (ind==(len)){
            ind = 0;
            $('.nav_item').each(function(index,elem){if (index!=(ind)){$(this).removeClass('active');}});
            $('.nav_item').eq(ind).addClass('active');
        }
    });
	//end slider tours----------------------------------------------	
	
	
	 //Banner ---------------------------------------------------------------------------------------------  
	banners();
	
    $('.grad_2').css({opacity:0});
	$('.over').css({opacity:0});
	
	if(MSIE){
		$('.grad_2').css({display:'none'});
	}
	
    function banners(){
		var banners = $(".scroll_2 .over").hover(bannerOverHandler, bannerOutHandler);
		var animateState = true;
		
		function bannerOverHandler(){
			
			if(MSIE){
				$(this).parent().find('.grad_2').css({display:'block'});
				
			}else{
				$(this).parent().find('.grad_2').stop().animate({opacity:1});
				$(this).parent().find('.grad_1').stop().delay(250).animate({opacity:0});
			}
			$(this).parent().find(".text_3").stop().delay(50).animate({color: '#6cbaea'}, 250, "easeOutSine", animationFinishHandler);
		}
		function bannerOutHandler(){
		
			if(MSIE){
				
				$(this).parent().find('.grad_2').css({display:'none'});
			}else{
				$(this).parent().find('.grad_2').stop().delay(250).animate({opacity:0});
			$(this).parent().find('.grad_1').stop().animate({opacity:1});
			}
			$(this).parent().find(".text_3").stop().delay(50).animate({color: '#989696'}, 250, "easeOutSine", animationFinishHandler);
		}
		function animationFinishHandler(){
			animateState = true;
		}
	}
	 
	 
	 
	 
	 //follow-icons-------------	 
	$('.follow-icon a').hover(function(){
		$(this).find('.img_icon').stop().animate({paddingTop:'7px'})
      $(this).find('p').stop().animate({color:'#f00'}, 550, 'easeOutSine')						 
	}, function(){
		$(this).find('.img_icon').stop().animate({paddingTop:'0px'})
      $(this).find('p').stop().animate({color:'#1E1E1E'}, 550, 'easeOutSine')							 
	})
	
		
		// scroller
    $('.scroll')
		.uScroll({
			axis:'y'
			,lay:'outside'
			,duration:600
			,easing:'easeInOutSine'
			,step:100
			,mousewheel:true
		})
		
		  $(document).mouseup(
		  function(){
            $('._shuttle').stop().animate({'backgroundPosition':'center top'},500,'easeOutExpo');
        })
		//end scroller


    /////////////////////////////////////////////////////////////////////////// 
    //                           content switch                              //
    ///////////////////////////////////////////////////////////////////////////
    
    var content=$('#content'),
			menu=$('.menu'),
			splash=$('.splash'),
			nav=$('.menu');
    
    $('ul#menu').superfish({
      delay:       700,
      animation:   {height:'show'},
      speed:       300,
      autoArrows:  false,
      dropShadows: false
    });

    
    nav.navs({
		useHash:true,
        defHash:'#!/',
		hoverIn:function(li){
		   	  $('>a ',li).css({color:'#fff'});
		   	  $('> a > span ',li).css({display:'block'}).stop().animate({opacity:1}, aniButtonDuration, 'easeOutCubic');
		},
		hoverOut:function(li){
		  if (!li.hasClass('with_ul') || !li.hasClass('sfHover')) {
              $('>a ',li).css({color:'#989696'});
		   	  $('> a > span ',li).stop().animate({opacity:0}, aniButtonDuration, 'easeOutCubic', function(){
		   	      $(this).css({display:'none'});
		   	  });
          }
		}				
    })
    
     content.tabs({
		preFu:function(_)
        {
            _.li.css({display:'none', top:'574px'});
            _.li.each(function(){
                if($(this).height() < 574){
                    $(this).height(574);
                } else {
                    $(this).height($(this).height()+0)
                }
            })
		}
		,actFu:function(_)
        {

            if(_.pren == undefined){
                aniDelay = 250;
            } else {
                if(_.n == -1 && _.pren == -1){
                    aniDelay = 250;
                } else {
                    aniDelay = 450;
                }
            }
            

            if(_.n == -1){
              
			   $('.cont_tint').css({opacity:0})
				content.stop().delay(aniDelay).animate({height:'0px'}, 650,'easeOutCubic');
                
				menu.stop().delay(aniDelay).animate({paddingTop:'860px'}, 650,'easeOutCubic');
					
            } else {
                content.stop().delay(aniDelay).animate({height:_.curr.height()+0}, 650,'easeOutCubic');
					  menu.stop().delay(aniDelay).animate({paddingTop:'340px'}, 650,'easeOutCubic');
					  
					  $('.cont_tint').css({opacity:1});
            }
            
        	if(_.curr){
				_.curr
					.stop()
					.delay(aniDelay).css({display:'block', top:content.height()}).animate({top:'0px'}, 650,'easeOutCubic');
            }

            
			if(_.prev){
			    _.prev 
    				.stop()
    				.animate({top:content.height()}, 350,'easeInSine', function(){
    				     $(this).css({display:'none'});
    			     });
            }
           
        }
		
	})
       
    nav.navs(function(n, _)
    {
		content.tabs(n);
	})
    
	
	 $(window).trigger('resize');
 
 
 	$(">a", ".active").stop(true).animate({color:'#ffffff'}, 0,'easeOutCubic');
})