<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search results</title>
    <meta charset="utf-8">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
    <meta name="description" content="Your description">
    <meta name="keywords" content="Your keywords">
    <meta name="author" content="Your name">    
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- font-awesome font -->
    <link rel="stylesheet" href="font/font-awesome.css" type="text/css" media="screen">
    <!-- fontello font -->
		<script src="js/jquery.js"></script>
        <script src="js/jquery.easing.1.3.js"></script>
        <script src="js/jquery-migrate-1.1.1.js"></script>
        <script src="js/superfish.js"></script>
        <script src="js/jquery.mobilemenu.js"></script>
         
        <script src="search/search.js"></script> 
        
        <script src="js/jquery.ui.totop.js"></script> 
             
      <!--[if lt IE 8]>
          <div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg"border="0"alt=""/></a></div>  
      <![endif]-->
  <!--[if lt IE 9]>
     
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <script src="assets/js/html5shiv.js"></script>
  <![endif]-->
</head>
<body>
<div class="main">
  <header>  
    <div class="container">
      <div class="row">
          <div class="span12 header-block">
              <h1 class="brand"><a href="index.html"><span>portland</span><strong>9</strong></a></h1> 
              <div class="navbar navbar_ clearfix">
                <div class="navbar-inner">                                                 
                  <div class="nav-collapse nav-collapse_ collapse">
                    <ul class="nav sf-menu clearfix">
                      <li><a href="index.html">Home</a></li>
                      <li class="sub-menu"><a href="index-1.html">About</a>
                      	<ul>
                          <li><a href="#">company</a></li>
                          <li><a href="#">team</a></li>
                          <li><a href="#">booking</a></li>
                          <li><a href="#">gallery</a></li>
                          <li><a href="#">directions</a></li>
                          <li><a href="#">faqs</a></li>
                        </ul>
                      </li>
                      <li><a href="index-2.html">Services</a></li>
                      <li><a href="index-3.html">Blog</a></li>
                      <li><a href="index-4.html">Contacts</a></li>
                    </ul>
                  </div>
                </div>
            </div>
          </div> 
        </div> 
      </div> 
  </header>
  
<div class="bg">  

  <!--==============================content=================================-->
  <div id="content"> 
    <div class="container">
       <div class="row">
          <div class="span12">
              <h3>Search result:</h3>
              <div id="search-results"></div>
          </div>
       </div>      
   </div>
  </div>  
</div>
<!--==============================footer=================================-->
  <footer>
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="footer-text"><h1 class="brand"><a href="index.html"><span>portland</span><strong>9</strong></a></h1> <strong>portland 9 &copy; 2013 &bull; <a href="index-5.html" class="footer-link">privacy policy</a></strong></div>  
            	<ul class="social-icons">
                	<li><a href="#" class="icon-facebook"></a></li>
                    <li><a href="#" class="icon-google-plus"></a></li>
                    <li><a href="#" class="icon-rss"></a></li>
                    <li><a href="#" class="icon-pinterest"></a></li>
                    <li><a href="#" class="icon-linkedin"></a></li>
                </ul>
            </div>  
        </div>  
    </div>
 </footer>
</div>
<script src="js/bootstrap.js"></script>
</body>
</html>