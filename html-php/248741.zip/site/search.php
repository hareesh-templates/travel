<!DOCTYPE html>
<html lang="en">
<head>
<title>Search</title>
<meta charset="utf-8">
<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/superfish.css">
<link rel="stylesheet" href="css/grid.css" />
<link href='http://fonts.googleapis.com/css?family=Lora:700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Sansita+One' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.1.min.js"></script>
<script src="search/search.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script>
		jQuery(document).ready(function() {
			$().UItoTop({ easingType: 'easeOutQuart' });
		});

</script>
<!--[if lt IE 8]>
   <div style=' clear: both; text-align:center; position: relative;'>
     <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
       <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
    </a>
  </div>
<![endif]-->
<!--[if lt IE 9]>
	<script src="js/html5.js"></script>
	<link rel="stylesheet" href="css/ie.css">
<![endif]-->
</head>
<body>
<!-- Header -->
<header>
  <div class="container_24">
    <div class="grid_24">
      <h1><a href="index.html">TaxiPark Fast and safe transportation</a></h1>
      <nav>
        <ul class="sf-menu">
          <li><a href="index.html">home</a>
          	 <ul>
              <li><a href="#">about us</a></li>
              <li><a href="#">Company Profile</a>
                <ul>
                  <li><a href="#">our work team</a></li>
                  <li><a href="#">testimonials</a></li>
                  <li><a href="#">news</a></li>
                  <li><a href="#">friends links</a></li>
                  <li><a href="#">Useful links</a></li>
                </ul>
              </li>
              <li><a href="#">Our advantages</a></li>
              <li><a href="#">partnership</a></li>
            </ul>
          </li>
          <li><a href="index-1.html">services</a></li>
          <li><a href="index-2.html">fares</a></li>
          <li><a href="index-3.html">blog</a></li>
          <li><a href="index-4.html">contacts</a></li>
        </ul>
        <div class="clear"></div>
      </nav>
      <div class="clear"></div>
    </div>
    <div class="clear"></div>
  </div>
</header>
<!--main-->
<div class="main">
<div class="content">
	<div class="container_24">
    	<div class="grid_24">
          	<h3>Search result:</h3>
			<div id="search-results"></div>
         </div>
        <div class="clear">	</div>
    </div>
</div>

</div>
<!--Footer-->
<footer>
  <div class="container_24">
    <div class="grid_24">
		<div class="copy">
        	<a href="#" class="footer_logo">TaxiPark</a> &copy; 2013 &nbsp;|&nbsp; <a href="index-5.html">Privacy Policy</a>
        </div>
        <div class="socials">
        	<a href="#"></a>
        	<a href="#"></a>
        	<a href="#"></a>
        	<a href="#"></a>
        </div>
    </div>
    <div class="clear"></div>
  </div>
</footer>
<!-- Footer end-->
</body>
</html>